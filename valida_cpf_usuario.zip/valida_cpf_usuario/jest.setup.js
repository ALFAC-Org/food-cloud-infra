// jest.setup.js
beforeEach(() => {
  expect.hasAssertions()
})
